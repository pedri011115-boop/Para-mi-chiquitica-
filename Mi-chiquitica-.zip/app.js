/**
 * ================================================================
 * PEDRO & IRINA — CINEMATIC LUXURY ROMANCE
 * app.js — Production Build (v2 — Real Photos + Locos)
 * Pure Vanilla JS · No Frameworks · GitHub Pages Ready
 * ================================================================
 */

'use strict';

/* ----------------------------------------------------------------
   CONSTANTS & CONFIG
---------------------------------------------------------------- */
const CONFIG = {
  PASSWORD:       'irina',
  START_DATE:     new Date('2026-01-09T00:00:00'),
  SLIDE_INTERVAL: 6500,
  LETTER_SPEED:   22,
  PARTICLE_COUNT: 40,
  PHOTOS:         11,  // 11 real photos
};

/* Full romantic letter (500+ words) */
const LETTER_TEXT = `Irina,

Hay palabras que se quedan cortas cuando intento describir lo que significas para mí. He pensado en cómo empezar esta carta decenas de veces, y siempre termino en el mismo lugar: en ti. En cómo llegaste a mi vida y la reorganizaste toda, sin pedirlo, sin forzarlo, simplemente siendo tú.

No te busqué con un plan. No tenía una lista de cómo debía ser la persona que cambiara mi mundo. Pero si la hubiera tenido, habrías superado cada punto con creces. Porque eres todo lo que imaginé y todo lo que nunca supe que necesitaba al mismo tiempo.

Desde el 9 de enero de 2026, cada día ha tenido un sabor distinto. Uno más cálido. Uno donde las cosas cotidianas dejan de serlo porque están compartidas contigo. Me doy cuenta de que antes existía, pero ahora vivo. Hay una diferencia enorme entre las dos cosas, y la descubrí gracias a ti.

Me gusta cómo me miras cuando crees que no me doy cuenta. Me gusta la forma en que ríes cuando algo te sorprende. Me gusta que tienes opiniones firmes y que no las cambias por nadie. Me gusta tu seriedad y tu ternura, que en ti no se contradicen, sino que conviven con una armonía que me parece increíble.

He aprendido cosas contigo que ningún libro me enseñó. Aprendí que el amor no siempre es ruido y drama. Que a veces el amor es exactamente esto: tú al lado mío, el silencio entre los dos que no pesa, sino que descansa. Aprendí que se puede sentir amor y también paz, y que no tenía que elegir entre uno y otro.

Quiero que sepas que en los días difíciles, pienso en ti. En que estás. En que existes. Y eso solo ya es suficiente para seguir. Eso es algo que nadie me había dado antes: la certeza de que no estoy solo en esto que llamamos vida.

No te prometo perfección. Te prometo honestidad. Te prometo que cuando me equivoque voy a reconocerlo. Te prometo que te voy a elegir todos los días, no porque tenga que hacerlo, sino porque quiero. Porque elegirte es la decisión más fácil y más clara que he tomado en mi vida.

Eres mi lugar favorito, Irina. No un lugar en el mapa, sino ese espacio donde me siento en casa sin importar dónde estemos. Ese lugar donde el tiempo se estira y las preocupaciones se achican.

Gracias por confiar en mí. Gracias por dejarme conocerte. Gracias por cada mensaje, cada mirada, cada momento compartido. Gracias por existir exactamente como eres.

Te amo hoy, mañana, y en todas las vidas que nos queden por vivir.

Tuyo siempre,`;

const PARTICLE_EMOJIS = ['❤️', '🌹', '✨', '💫', '🌸', '💛', '🤍'];

/* ----------------------------------------------------------------
   DOM REFERENCES
---------------------------------------------------------------- */
const $ = (id) => document.getElementById(id);
const $$ = (sel) => document.querySelectorAll(sel);

const DOM = {
  loading:       $('loadingOverlay'),
  accessScreen:  $('accessScreen'),
  introScreen:   $('introScreen'),
  mainSite:      $('mainSite'),
  accessInput:   $('accessInput'),
  accessBtn:     $('accessBtn'),
  accessError:   $('accessError'),
  introText1:    $('introText1'),
  introText2:    $('introText2'),
  introLogo:     $('introLogo'),
  startBtn:      $('startJourneyBtn'),
  cDays:         $('cDays'),
  cHours:        $('cHours'),
  cMinutes:      $('cMinutes'),
  cSeconds:      $('cSeconds'),
  slideshow:     $('slideshow'),
  slides:        $$('.slide'),
  slideDots:     $('slideshow') ? $('slideshow').querySelector('.slide-dots') : null,
  envelope:      $('envelope'),
  petalContainer:$('petalContainer'),
  letterContent: $('letterContent'),
  letterText:    $('letterText'),
  finaleMosaic:  $('finaleMosaic'),
  musicPlayer:   $('musicPlayer'),
  bgAudio:       $('bgAudio'),
  playerToggle:  $('playerToggle'),
  playerIcon:    $('playerIcon'),
  playerMute:    $('playerMute'),
  muteIcon:      $('muteIcon'),
  playerVinyl:   $('playerVinyl'),
  playerProgress:$('playerProgressBar'),
  canvas:        $('particleCanvas'),
};

/* ----------------------------------------------------------------
   STATE
---------------------------------------------------------------- */
const STATE = {
  currentSlide:    0,
  slideTimer:      null,
  letterTyping:    false,
  letterDone:      false,
  musicStarted:    false,
  audioPlaying:    false,
  particleAnimId:  null,
  counterInterval: null,
};

/* ================================================================
   1. INIT
================================================================ */
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    DOM.loading.classList.add('fade-out');
    setTimeout(() => DOM.loading.classList.add('hidden'), 600);
  }, 700);

  DOM.accessInput?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') handleAccessSubmit();
  });
  DOM.accessBtn?.addEventListener('click', handleAccessSubmit);
  DOM.startBtn?.addEventListener('click', () => {
    document.getElementById('gallerySection')?.scrollIntoView({ behavior: 'smooth' });
  });

  initParticles();

  DOM.envelope?.addEventListener('click', openEnvelope);
  DOM.envelope?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openEnvelope(); }
  });

  DOM.playerToggle?.addEventListener('click', toggleMusic);
  DOM.playerMute?.addEventListener('click', toggleMute);
  DOM.bgAudio?.addEventListener('timeupdate', updateMusicProgress);

  buildFinaleMosaic();
  buildSlideDots();

  DOM.slideshow?.querySelector('.prev')?.addEventListener('click', () => {
    goToSlide((STATE.currentSlide - 1 + CONFIG.PHOTOS) % CONFIG.PHOTOS);
    resetSlideTimer();
  });
  DOM.slideshow?.querySelector('.next')?.addEventListener('click', () => {
    goToSlide((STATE.currentSlide + 1) % CONFIG.PHOTOS);
    resetSlideTimer();
  });

  setupScrollObserver();
  markScrollRevealTargets();
});

/* ================================================================
   2. ACCESS SCREEN
================================================================ */
function handleAccessSubmit() {
  const val = DOM.accessInput?.value.trim().toLowerCase();
  if (!val) { showAccessError('Por favor escribe un nombre 💛'); return; }

  if (val === CONFIG.PASSWORD.toLowerCase()) {
    DOM.accessError.textContent = '';
    DOM.accessInput.disabled = true;
    DOM.accessBtn.disabled   = true;
    DOM.accessBtn.style.opacity = '0.5';

    DOM.accessScreen.style.transition = 'opacity 0.8s ease';
    DOM.accessScreen.style.opacity    = '0';
    setTimeout(() => {
      DOM.accessScreen.classList.remove('active');
      DOM.accessScreen.classList.add('hidden');
      startCinematicIntro();
    }, 800);
  } else {
    showAccessError('Ese no es su nombre... intenta de nuevo 🤍');
    DOM.accessInput.value = '';
    DOM.accessInput.focus();
    DOM.accessError.style.animation = 'none';
    void DOM.accessError.offsetWidth;
    DOM.accessError.style.animation = 'shake 0.5s ease';
  }
}

function showAccessError(msg) {
  DOM.accessError.textContent = msg;
}

/* ================================================================
   3. CINEMATIC INTRO
================================================================ */
function startCinematicIntro() {
  DOM.introScreen.classList.add('active');

  setTimeout(() => DOM.introText1.classList.add('visible'), 400);

  setTimeout(() => {
    DOM.introText1.style.transition = 'opacity 0.8s ease';
    DOM.introText1.style.opacity    = '0';
  }, 2600);

  setTimeout(() => {
    DOM.introText2.classList.remove('hidden');
    setTimeout(() => DOM.introText2.classList.add('visible'), 50);
  }, 3200);

  setTimeout(() => {
    DOM.introText2.style.transition = 'opacity 0.8s ease';
    DOM.introText2.style.opacity    = '0';
  }, 5400);

  setTimeout(() => {
    DOM.introLogo.classList.remove('hidden');
    setTimeout(() => DOM.introLogo.classList.add('visible'), 50);
  }, 6000);

  setTimeout(() => {
    DOM.introScreen.style.transition = 'opacity 1s ease';
    DOM.introScreen.style.opacity    = '0';
    setTimeout(() => {
      DOM.introScreen.classList.remove('active');
      launchMainSite();
    }, 1000);
  }, 7800);
}

/* ================================================================
   4. MAIN SITE LAUNCH
================================================================ */
function launchMainSite() {
  DOM.mainSite.classList.remove('hidden');
  DOM.mainSite.classList.add('visible');
  startCounter();
  startSlideshow();
  showMusicPlayer();
  window.scrollTo({ top: 0, behavior: 'instant' });
}

/* ================================================================
   5. COUNTER
================================================================ */
function startCounter() {
  updateCounter();
  STATE.counterInterval = setInterval(updateCounter, 1000);
}

function updateCounter() {
  const diff = new Date() - CONFIG.START_DATE;
  if (diff < 0) return;

  const total   = Math.floor(diff / 1000);
  const seconds = total % 60;
  const minutes = Math.floor(total / 60) % 60;
  const hours   = Math.floor(total / 3600) % 24;
  const days    = Math.floor(total / 86400);

  const pad = (n, l = 2) => String(n).padStart(l, '0');

  setCounterValue(DOM.cDays,    pad(days, 3));
  setCounterValue(DOM.cHours,   pad(hours));
  setCounterValue(DOM.cMinutes, pad(minutes));
  setCounterValue(DOM.cSeconds, pad(seconds));
}

function setCounterValue(el, val) {
  if (!el || el.textContent === val) return;
  el.textContent = val;
  el.classList.add('tick');
  setTimeout(() => el.classList.remove('tick'), 300);
}

/* ================================================================
   6. SLIDESHOW
================================================================ */
function buildSlideDots() {
  if (!DOM.slideDots) return;
  DOM.slideDots.innerHTML = '';
  Array.from(DOM.slides).forEach((_, i) => {
    const dot = document.createElement('button');
    dot.className = 'slide-dot' + (i === 0 ? ' active' : '');
    dot.setAttribute('role', 'tab');
    dot.setAttribute('aria-label', `Foto ${i + 1}`);
    dot.setAttribute('aria-selected', i === 0 ? 'true' : 'false');
    dot.addEventListener('click', () => { goToSlide(i); resetSlideTimer(); });
    DOM.slideDots.appendChild(dot);
  });
}

function goToSlide(index) {
  const slides = Array.from(DOM.slides);
  const dots   = Array.from($$('.slide-dot'));

  slides[STATE.currentSlide]?.classList.remove('active');
  dots[STATE.currentSlide]?.classList.remove('active');
  dots[STATE.currentSlide]?.setAttribute('aria-selected', 'false');

  STATE.currentSlide = index;

  slides[STATE.currentSlide]?.classList.add('active');
  dots[STATE.currentSlide]?.classList.add('active');
  dots[STATE.currentSlide]?.setAttribute('aria-selected', 'true');

  // Reset ken-burns animation
  const imgEl = slides[STATE.currentSlide]?.querySelector('.slide-img');
  if (imgEl) {
    imgEl.style.animation = 'none';
    void imgEl.offsetWidth;
    imgEl.style.animation = '';
  }
}

function startSlideshow() {
  STATE.slideTimer = setInterval(() => {
    goToSlide((STATE.currentSlide + 1) % Array.from(DOM.slides).length);
  }, CONFIG.SLIDE_INTERVAL);
}

function resetSlideTimer() {
  clearInterval(STATE.slideTimer);
  startSlideshow();
}

/* ================================================================
   7. ENVELOPE & LETTER
================================================================ */
function openEnvelope() {
  if (DOM.envelope.classList.contains('opened')) return;
  DOM.envelope.classList.add('opening');

  setTimeout(() => {
    DOM.envelope.classList.add('opened');
    const hint = DOM.envelope.querySelector('.envelope-hint');
    if (hint) hint.style.display = 'none';
    spawnPetals();
    setTimeout(() => {
      DOM.letterContent.classList.remove('hidden');
      typewriterLetter();
    }, 600);
  }, 800);
}

function spawnPetals() {
  const petals = ['🌸','🌹','🌺','💮','🏵️','💛','❤️','✨'];
  for (let i = 0; i < 45; i++) {
    setTimeout(() => {
      const el = document.createElement('span');
      el.className = 'petal';
      el.textContent = petals[Math.floor(Math.random() * petals.length)];
      el.style.left = `${Math.random() * 100}vw`;
      el.style.top  = '-30px';
      el.style.fontSize = `${0.8 + Math.random() * 1.4}rem`;
      const dur = 2.5 + Math.random() * 3;
      el.style.animationDuration = `${dur}s`;
      DOM.petalContainer.appendChild(el);
      setTimeout(() => el.remove(), dur * 1000 + 200);
    }, i * 80);
  }
}

function typewriterLetter() {
  if (STATE.letterTyping || STATE.letterDone) return;
  STATE.letterTyping = true;

  const cursor = document.createElement('span');
  cursor.className = 'letter-cursor';
  DOM.letterText.appendChild(cursor);

  let i = 0;
  const text = LETTER_TEXT;

  function type() {
    if (i < text.length) {
      cursor.insertAdjacentText('beforebegin', text[i]);
      i++;
      const ch = text[i - 1];
      const isPunct = ['.', ',', '!', '?', '\n'].includes(ch);
      const delay = isPunct
        ? CONFIG.LETTER_SPEED * 8
        : CONFIG.LETTER_SPEED + (Math.random() * 10 - 5);
      setTimeout(type, Math.max(5, delay));
    } else {
      STATE.letterTyping = false;
      STATE.letterDone   = true;
      cursor.remove();
      setTimeout(() => {
        $$('.poem-stanza').forEach((el, idx) => {
          setTimeout(() => el.classList.add('visible'), idx * 400);
        });
      }, 800);
    }
  }
  type();
}

/* ================================================================
   8. FINALE MOSAIC (11 photos)
================================================================ */
function buildFinaleMosaic() {
  if (!DOM.finaleMosaic) return;
  DOM.finaleMosaic.innerHTML = '';
  for (let i = 1; i <= CONFIG.PHOTOS; i++) {
    const tile = document.createElement('div');
    tile.className = 'finale-tile';
    tile.style.backgroundImage = `url('assets/photos/photo${i}.jpg')`;
    tile.style.setProperty('--delay', `${(i - 1) * 0.4}s`);
    DOM.finaleMosaic.appendChild(tile);
  }
}

/* ================================================================
   9. MUSIC PLAYER
================================================================ */
function showMusicPlayer() {
  DOM.musicPlayer?.classList.remove('hidden');
}

function toggleMusic() {
  if (!DOM.bgAudio) return;

  if (!STATE.musicStarted) {
    DOM.bgAudio.volume = 0.6;
    DOM.bgAudio.play().then(() => {
      STATE.musicStarted = true;
      STATE.audioPlaying = true;
      DOM.playerIcon.textContent = '⏸';
      DOM.playerVinyl.classList.add('spinning');
    }).catch(() => {
      DOM.playerIcon.textContent = '▶';
    });
    return;
  }

  if (STATE.audioPlaying) {
    DOM.bgAudio.pause();
    STATE.audioPlaying = false;
    DOM.playerIcon.textContent = '▶';
    DOM.playerVinyl.classList.remove('spinning');
  } else {
    DOM.bgAudio.play();
    STATE.audioPlaying = true;
    DOM.playerIcon.textContent = '⏸';
    DOM.playerVinyl.classList.add('spinning');
  }
}

function toggleMute() {
  if (!DOM.bgAudio) return;
  DOM.bgAudio.muted = !DOM.bgAudio.muted;
  DOM.muteIcon.textContent = DOM.bgAudio.muted ? '🔇' : '🔊';
}

function updateMusicProgress() {
  if (!DOM.bgAudio || !DOM.playerProgress || !DOM.bgAudio.duration) return;
  const pct = (DOM.bgAudio.currentTime / DOM.bgAudio.duration) * 100;
  DOM.playerProgress.style.width = `${pct}%`;
}

/* ================================================================
   10. CANVAS PARTICLES
================================================================ */
function initParticles() {
  const canvas = DOM.canvas;
  const ctx    = canvas?.getContext('2d');
  if (!canvas || !ctx) return;

  const resize = () => {
    canvas.width  = window.innerWidth;
    canvas.height = window.innerHeight;
  };
  resize();
  window.addEventListener('resize', resize, { passive: true });

  const particles = [];
  for (let i = 0; i < CONFIG.PARTICLE_COUNT; i++) {
    particles.push(createParticle(canvas));
  }

  function createParticle(c) {
    return {
      x:       Math.random() * c.width,
      y:       Math.random() * c.height,
      vx:      (Math.random() - 0.5) * 0.35,
      vy:      -(0.2 + Math.random() * 0.55),
      size:    8 + Math.random() * 10,
      alpha:   0.1 + Math.random() * 0.45,
      emoji:   PARTICLE_EMOJIS[Math.floor(Math.random() * PARTICLE_EMOJIS.length)],
      life:    0,
      maxLife: 220 + Math.random() * 280,
    };
  }

  function render() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach((p, idx) => {
      p.x    += p.vx;
      p.y    += p.vy;
      p.life += 1;

      const prog = p.life / p.maxLife;
      const fade = prog < 0.1
        ? prog / 0.1
        : prog > 0.8
          ? 1 - (prog - 0.8) / 0.2
          : 1;

      ctx.globalAlpha = p.alpha * fade;
      ctx.font        = `${p.size}px serif`;
      ctx.fillText(p.emoji, p.x, p.y);

      if (p.life >= p.maxLife || p.y < -30) {
        const np = createParticle(canvas);
        np.y  = canvas.height + 20;
        np.vy = -(0.2 + Math.random() * 0.55);
        particles[idx] = np;
      }
    });
    ctx.globalAlpha  = 1;
    STATE.particleAnimId = requestAnimationFrame(render);
  }
  render();
}

/* ================================================================
   11. SCROLL OBSERVER
================================================================ */
function setupScrollObserver() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -50px 0px' });

  $$('.scroll-reveal').forEach((el) => observer.observe(el));
}

function markScrollRevealTargets() {
  [
    '#counterSection .counter-container',
    '#gallerySection .gallery-label',
    '#letterSection .letter-section-title',
    '#finaleSection .finale-content',
  ].forEach((sel) => {
    document.querySelector(sel)?.classList.add('scroll-reveal');
  });
}

/* ================================================================
   12. TOUCH SWIPE
================================================================ */
(function initSwipe() {
  const ss = DOM.slideshow;
  if (!ss) return;
  let startX = 0, startY = 0;

  ss.addEventListener('touchstart', (e) => {
    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;
  }, { passive: true });

  ss.addEventListener('touchend', (e) => {
    const dx = e.changedTouches[0].clientX - startX;
    const dy = e.changedTouches[0].clientY - startY;
    if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 40) {
      const total = Array.from(DOM.slides).length;
      goToSlide(dx < 0
        ? (STATE.currentSlide + 1) % total
        : (STATE.currentSlide - 1 + total) % total
      );
      resetSlideTimer();
    }
  }, { passive: true });
})();

/* ================================================================
   13. KEYBOARD
================================================================ */
document.addEventListener('keydown', (e) => {
  if (DOM.mainSite.classList.contains('hidden')) return;
  const total = Array.from(DOM.slides).length;
  if (e.key === 'ArrowRight') { goToSlide((STATE.currentSlide + 1) % total); resetSlideTimer(); }
  else if (e.key === 'ArrowLeft') { goToSlide((STATE.currentSlide - 1 + total) % total); resetSlideTimer(); }
  else if (e.key === ' ' && document.activeElement?.tagName !== 'INPUT') {
    e.preventDefault();
    toggleMusic();
  }
});

/* ================================================================
   14. VISIBILITY CHANGE
================================================================ */
document.addEventListener('visibilitychange', () => {
  if (!DOM.bgAudio) return;
  if (document.hidden && STATE.audioPlaying) DOM.bgAudio.pause();
  else if (!document.hidden && STATE.audioPlaying) DOM.bgAudio.play();
});

/* ================================================================
   15. REDUCED MOTION
================================================================ */
if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  document.documentElement.classList.add('reduced-motion');
}

/* END OF APP.JS */
